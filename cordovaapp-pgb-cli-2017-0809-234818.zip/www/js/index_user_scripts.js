/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  Back */
    $(document).on("click", ".uib_w_9", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  .uib_w_1 */
    $(document).on("click", ".uib_w_1", function(evt)
    {
         /*global activate_page */
         activate_page("#info"); 
         return false;
    });
    
        /* button  Button */
    
    
        /* button  Button */
    
    
        /* button  Button */
    
    
        /* button  Button */
    $(document).on("click", ".uib_w_2", function(evt)
    {
         /*global activate_page */
         activate_page("#Cordova"); 
         return false;
    });
    
        /* button  .uib_w_18 */
    
    
        /* button  .uib_w_18 */
    $(document).on("click", ".uib_w_18", function(evt)
    {
         /* Other options: .modal("show")  .modal("hide")  .modal("toggle")
         See full API here: http://getbootstrap.com/javascript/#modals 
            */
        
         $(".uib_w_19").modal("toggle");  
         return false;
    });
    
        /* button  Pendapatan */
    $(document).on("click", ".uib_w_3", function(evt)
    {
         /*global activate_page */
         activate_page("#pendapatan"); 
         return false;
    });
    
        /* button  Bayaran */
    $(document).on("click", ".uib_w_20", function(evt)
    {
         /*global activate_page */
         activate_page("#Bayaran"); 
         return false;
    });
    
        /* button  Ranking */
    $(document).on("click", ".uib_w_21", function(evt)
    {
         /*global activate_page */
         activate_page("#Ranking"); 
         return false;
    });
    
        /* button  Info Bank */
    $(document).on("click", ".uib_w_22", function(evt)
    {
         /*global activate_page */
         activate_page("#InfoBank"); 
         return false;
    });
    
        /* button  Idea Anda */
    $(document).on("click", ".uib_w_4", function(evt)
    {
         /*global activate_page */
         activate_page("#IdeaAnda"); 
         return false;
    });
    
        /* button  Info */
    $(document).on("click", ".uib_w_10", function(evt)
    {
         /*global activate_page */
         activate_page("#Info"); 
         return false;
    });
    
        /* button  .uib_w_33 */
    $(document).on("click", ".uib_w_33", function(evt)
    {
         /*global activate_page */
         activate_page("#menu"); 
         return false;
    });
    
        /* button  .uib_w_34 */
    $(document).on("click", ".uib_w_34", function(evt)
    {
         /*global activate_page */
         activate_page("#menu"); 
         return false;
    });
    
        /* button  .uib_w_35 */
    
    
        /* button  .uib_w_36 */
    
    
        /* button  .uib_w_37 */
    
    
        /* button  .uib_w_38 */
    
    
        /* button  .uib_w_39 */
    $(document).on("click", ".uib_w_39", function(evt)
    {
         /*global activate_page */
         activate_page("#menu"); 
         return false;
    });
    
        /* button  Info */
    
    
        /* button  1Button */
    
    
        /* button  1Button */
    
    
        /* button  1Button */
    
    
        /* button  1Button */
    $(document).on("click", ".uib_w_51", function(evt)
    {
         /* Other options: .modal("show")  .modal("hide")  .modal("toggle")
         See full API here: http://getbootstrap.com/javascript/#modals 
            */
        
         $(".uib_w_50").modal("toggle");  
         return false;
    });
    
        /* button  Button */
    
    
        /* button  Button */
    
    
        /* button  Summit2 */
    
    
        /* button  Summit2 */
    $(document).on("click", ".uib_w_43", function(evt)
    {
        /* your code goes here */ 
         return false;
    });
    
        /* button  Button */
    
    
        /* button  Info2 */
    
    
        /* button  Info3 */
    
    
        /* button  Info4 */
    
    
        /* button  Button */
    
    
        /* button  Info5 */
    
    
        /* button  Info6 */
    $(document).on("click", ".uib_w_65", function(evt)
    {
         /* Other options: .modal("show")  .modal("hide")  .modal("toggle")
         See full API here: http://getbootstrap.com/javascript/#modals 
            */
        
         $(".uib_w_66").modal("toggle");  
         return false;
    });
    
        /* button  .uib_w_38 */
    
    
        /* button  .uib_w_38 */
    $(document).on("click", ".uib_w_38", function(evt)
    {
         /*global activate_page */
         activate_page("#menu"); 
         return false;
    });
    
        /* button  .uib_w_37 */
    $(document).on("click", ".uib_w_37", function(evt)
    {
         /*global activate_page */
         activate_page("#pendapatan"); 
         return false;
    });
    
        /* button  .uib_w_36 */
    $(document).on("click", ".uib_w_36", function(evt)
    {
         /*global activate_page */
         activate_page("#pendapatan"); 
         return false;
    });
    
        /* button  .uib_w_35 */
    $(document).on("click", ".uib_w_35", function(evt)
    {
         /*global activate_page */
         activate_page("#pendapatan"); 
         return false;
    });
     
        /* button  Summit1 */
    $(document).on("click", ".uib_w_49", function(evt)
    {
        /* your code goes here */ 
         return false;
    });
     	
      /* button  Info */
    $(document).on("click", ".uib_w_60", function(evt)
    {
   	
alert("Berfungsi untuk anda melihat up to date ranking anda,Bonus ranking akan di berikan setiap setahun sekali ");

        /* your code goes here */ 
         return false;
    });
    
        /* button  Info */
    $(document).on("click", ".uib_w_62", function(evt)
    {
        	
alert("segala bayaran payslip anda akan di update dalam sistem bayaran ini");

        /* your code goes here */ 
         return false;
    });
    
        /* button  Info */
    $(document).on("click", ".uib_w_56", function(evt)
    {
        	
alert("Segala butiran bank anda perlu di isi untuk memudahkan kami membuat pembayaran ke dalam akaun bank anda");

        /* your code goes here */ 
         return false;
    });
    
        /* button  Info */
    $(document).on("click", ".uib_w_53", function(evt)
    {
        	
alert("Jika anda ada idea baru atau ada satu impian untuk memiliki sebuah aplikasi android atau ios. Boleh beri idea anda di sini. kami akan cuba merialisasikan impian anda");

        /* your code goes here */ 
         return false;
    });
    
        /* button  Info */
    $(document).on("click", ".uib_w_50", function(evt)
    {
        
alert("anda hanya perlu membiarkan sistem cordova ini bergerak secara aktif");

        /* your code goes here */ 
         return false;
    });
    
        /* button  Info */
    $(document).on("click", ".uib_w_50", function(evt)
    {
        /* your code goes here */ 
         return false;
    });
    
        /* button  Info */
    $(document).on("click", ".uib_w_50", function(evt)
    {
        /* your code goes here */ 
         return false;
    });
    
        /* button  summit1 */
    $(document).on("click", ".uib_w_7", function(evt)
    {
         /*global activate_page */
         activate_page("#menu"); 
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
